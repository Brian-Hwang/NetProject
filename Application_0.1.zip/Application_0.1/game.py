from time import sleep
from cProfile import run
from platform import platform
from numpy import character
import pygame
import random

pygame.init()
pygame.mixer.init()

gameplay_font = pygame.font.SysFont("dejavuserif", 20)
endgame_font =  pygame.font.SysFont("dejavuserif", 50)

fd = open('pro_output.txt', 'r')
count = 0
while True:
    data = fd.readline()
    if not data: 
        break
    if data.count('1') > count:
        count = data.count('1')
print("count : " + str(count))
fd.close()


screen_width = 500
screen_height = 500
pygame.display.set_caption("Network project")  # caption 넣기
screen = pygame.display.set_mode((screen_width, screen_height))  # 창크기 지정

now = 0
player_dir = 0


background = pygame.image.load("background.jpg")
background = pygame.transform.scale(background, (500, 500))
#배경 정보

player = pygame.image.load("player_no_background2.png")
player = pygame.transform.scale(player, (50, 50))
player_height = player.get_size()[1]
player_width = player.get_size()[0]
player_pos_x = 5 * 50
player_pos_y = screen_height - player_height
#player 정보

enemy = []
enemy_height = []
enemy_width = []
enemy_pos_x = []
enemy_pos_y = []
#enemy_rect = []
for i in range(count):
    enemy.append(pygame.image.load("enemy_no_background.png"))
    enemy[i] = pygame.transform.scale(enemy[i], (50, 50))
    enemy_height.append(enemy[i].get_size()[1])
    enemy_width.append(enemy[i].get_size()[0])
    enemy_pos_x.append(-50)
    enemy_pos_y.append(-50)
    #enemy_rect[i] = enemy[i].get_rect()
#enemy 정보
which_enemy = 0

clock = pygame.time.Clock()
running = 1
speed = 80

start_ticks = pygame.time.get_ticks()
elapsed_time = 0
end_time =0

def display_time(time):
    curr_time = gameplay_font.render(f"Time : {time}", True, (255, 255, 255))
    screen.blit(curr_time, (370, 20))
#시간 표시

def end_game(time):
    end_time = endgame_font.render(f"Final Time : {time}", True, (255, 255, 255))
    game_over = endgame_font.render(f"Game Over", True, (255, 255, 255))
    screen.blit(game_over, (130, 150))
    screen.blit(end_time, (70, 250))

pygame.mixer.music.load("song.mp3")
pygame.mixer.music.play()


fd = open('pro_output.txt', 'r')
len_one = 0
while (running ==1 or running ==2):
    sleep(0.5)
    data = fd.readline()
    if not data:
        print("끝")
        break
    pro_data = data[0:10]
    print(pro_data)
    back_data = data[90:100]
    one_index = []
    two_index = 5

    for i in range(10):
        if pro_data[i] == '1':
            one_index.append(i)
        if back_data[i] == '2':
            two_index = i

    player_pos_x = two_index * 50
    
    #플레이어 초기 위치

    for i in range(count):
        if enemy_pos_y[i] >= 0 and enemy_pos_y[i] < screen_height - enemy_height[i]:
            enemy_pos_y[i] += 50
        elif enemy_pos_y[i] >= screen_height - enemy_height[i]:
            enemy_pos_x[i] = -50
            enemy_pos_y[i] = -50

    for i in range(count):
        len_one = len(one_index)
        if len_one == 0: 
            break

        if enemy_pos_y[i] == -50:
            enemy_pos_x[i] = one_index[0] * 50
            enemy_pos_y[i] = 0
            del one_index[0]

    clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = 0

        #key = pygame.key.get_pressed()

        #if key[pygame.K_LEFT] == 1:
        # player_pos_x -= speed * clock.get_time() / 1000  # 초당으로 하기 때문에 프레임별로 불규칙해질 걱정 없음

        #if key[pygame.K_RIGHT] == 1:
        # player_pos_x += speed * clock.get_time() / 1000

    #방향키 눌렀을 때 움직이기
    
    if player_pos_x < 0:
        player_pos_x = 50 * two_index
        #player_pos_x = 0 
         
    if player_pos_x > screen_width - player_width:
         player_pos_x = screen_width - player_width

    #화면 밖 나간경우 처리 

    if player_pos_x == 0:
         player_dir =0

    if player_pos_x == screen_width - player_width:
         player_dir = 1

    if player_dir == 0:
         player_pos_x += 50 * clock.get_time() / 1000
    else : 
          player_pos_x -= 50 * clock.get_time() / 1000


    #적 위치 처리 

    player_rect = player.get_rect()
    player_rect.x = player_pos_x
    player_rect.y = player_pos_y
    
    #for i in range(count):
        #enemy_rect[i].x = enemy_pos_x[i]
        #enemy_rect[i].y = enemy_pos_y[i]
        
        #if player_rect.colliderect(enemy_rect[i]):
           #print('충돌')
            #running = False
            
    #충돌 위한 변수

    
    #충돌 검사 
    if(running==1):
        screen.blit(background,(0,0))
        screen.blit(player,(player_pos_x,player_pos_y))
        for i in range(count):
            screen.blit(enemy[i],(enemy_pos_x[i],enemy_pos_y[i]))
    
        elapsed_time = (pygame.time.get_ticks() - start_ticks) / 1000
        display_time(elapsed_time)
    #경과 시간 표시 추가
        
    if(elapsed_time > 5 and running == 1):
        end_time = elapsed_time
        running = 2 #end screen 출력
    
    if(running == 2):
        end_game(end_time)
        
    pygame.display.update()   
    
    
    #게임 종료 시 최종 시간 출력

        
fd.close()
pygame.mixer.quit()    
pygame.quit()
